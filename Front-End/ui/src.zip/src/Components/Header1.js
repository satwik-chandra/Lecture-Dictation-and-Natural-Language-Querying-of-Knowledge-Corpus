import React from 'react'
import logoUrl from './trinityHeader.png'

export const Header1 = () => {
    return 
    (
        <div className="header1">
              <img src={logoUrl} alt="Trinity" /> 
      </div>
    )
}; 
export default Header1
